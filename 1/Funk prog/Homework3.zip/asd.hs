module Homework3 where
    veryPutIntoList :: a -> [[a]]
    veryPutIntoList x = [[x]]

    intervalWithSkip :: Int -> Int -> [Int]
    intervalWithSkip x y = if x>y then [] else [x, x+2..y]
    

    condAddToList :: a -> Bool -> [a] -> [a] -> [a]
    condAddToList b c d e = if c then d ++ (b : e) else d ++ e

    fifthRoot :: Integer -> Integer
    fifthRoot x = floor (fromIntegral x ** (1/5))
